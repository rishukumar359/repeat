
function Property({arr}){  
        let a=true 
        

        return( 
           <div> 
               
           <div> { a && <div>thank you</div>  }</div>  
            
            </div>
        )
    

} 
export default Property; 