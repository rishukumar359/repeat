import React from 'react';
class Well extends React.Component {
    render() { 
        return (
        <div > 
            <div>
            <h2>welcome everyone1</h2>;
            </div>  
            {
            <div> 
                
            
                    <h2>welcome everyone3</h2>
            
            </div> 
    }
            
        </div> 
        )

    }
  }
  //ReactDOM.render(<Well />) 
  export default Well;