import logo from './logo.svg';
import './App.css'; 
import Button from 'react-bootstrap/Button';
import React, { useState } from 'react';
// import Welcome from './Welcome.jsx' ; 
// import Wel from './Welcome.jsx' ;
// import Well from './class.jsx'  
// import Property from './property.jsx'
// import Arr from './components.jsx'  
//  import Clock from './Clock.jsx' 
//  import Abc from './Time.jsx' 
//  import Basic from './Formic.jsx' 
import  Emailval from './Emailval.jsx' ; 
import  Emailval1 from './Emailval1.jsx' ; 
import  Hello from './Hello.jsx' ;
import  Api1 from './Api1.jsx' ; 
import  Api2 from './Api2.jsx' ;
import  Api3 from './Api3.jsx' ;  
import  Api4 from './Api4.jsx' ;
import  Getuser from './getuser.jsx';
import  Getuser1 from './getuser1.jsx';
import  Basic from './getuser2.jsx';

import  Model2 from './model.jsx' ;


import Nationality from './nationality.jsx';
function App() {  

  let arr=[1,2,3,4,5]
  
  let dic=[{fname:"rishu",
  lname:"kumar", 
  email:"ri@gmail.com",
  age:22,
  nationality:'indian',
  indian:true,
  state:'bihar',
  country:"india"}, 

  {fname:"roshan",
  lname:"kumar", 
  email:"rk@gmail.com",
  age:15,
  nationality:'indian',
  indian:true,
  state:'bihar',
  country:"india"}, 

  {fname:"pradeep",
  lname:"vaishya", 
  email:"pk@gmail.com",
  age:22,
  nationality:'indian',
  indian:true,
  state:'mp',
  country:"india"}, 

  {fname:"david r",
  lname:"warne", 
  email:"dv@gmail.com",
  age:32,
  nationality:'ausi',
  indian:false,
  state:'sydney',
  country:"aus"},

    ]  
    
//email validation 
let emaildic=[{'rishu@gmail.com':'123'},{'kumar@gmail.com':'1234'},{'ri@gmail.com':'12345'}]
  return (
    <div className="App"> 
        {/* <Property  arr={"rishu1"}/>  */} 
        {/* <Arr> </Arr> */}
        {/* <Nationality  ar={dic}/>  */}
        {/* const root = ReactDOM.createRoot(document.getElementById('root')); */}
       {/* <Abc/> */}
        {/* <Clock></Clock>  */}
        {/* <Form emaildic={emaildic}/> */} 
       {/* <Emailval1/>  */}
       
        {/* <Api4></Api4> */}
       {/* <Api2></Api2>    */}
       {/* <Api2></Api2> */}
       
       {/* <Getuser></Getuser>  */}
       <Getuser1></Getuser1>
      {/* <Basic></Basic> */}

       {/* <Button variant="primary" onClick={handleShow}>
       click
       
     </Button> */}
   
       {/* <Model2 show={show} setShow={false} handleClose={handleClose} handleShow={handleShow}/>  */}
      
    
       
       {/* <Api1></Api1> */}
     
    </div>
  );
}

export default App;
