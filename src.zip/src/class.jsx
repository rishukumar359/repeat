import React from 'react';
class Well extends React.Component {
    render() { 
        return (
        
             <React.Fragment>
             <div>
            <h2>welcome everyone2</h2>;
            </div>
            <div>
            <h2>welcome everyone2</h2>;
            </div>
             </React.Fragment>
        
            
            
            
        
    
        )

    }
  }
  //ReactDOM.render(<Well />) 
  export default Well;