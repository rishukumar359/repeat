function Welcome(){ 
    let arr=[1,2,3,4,5]  
    return arr

function Wel(){
    return 'wel';
} 
}