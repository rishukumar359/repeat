import { useCallback } from "react"
import { useState } from "react"

const User=()=>{
    [users,setUsers]= useState(null) 
    [users,setUsers]= useState(null)
    [users,setUsers]= useState(null)
} 


const getUserData=useCallback(async()=>{
    try{
         const response= await fetch("http://")
    } 
    catch{

    }
})